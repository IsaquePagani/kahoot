import { DEFAULTS, solveQuestion, validateQuestion } from './lib/solver.js';

const protectStorage = chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
const cache = new Map();
const pending = new Map();
let revision = 0;

function allowedSender(sender) {
  try {
    const url = new URL(sender.url);
    return url.protocol === 'https:' && ['kahoot.it', 'kahoot.com'].some(host => url.hostname === host || url.hostname.endsWith(`.${host}`));
  } catch { return false; }
}

async function settings() {
  await protectStorage;
  const saved = await chrome.storage.local.get(['geminiApiKey', 'model', 'autoSolve', 'autoClick']);
  // An older OpenAI model/key must never be reused for a different provider.
  if (saved.model && !saved.model.startsWith('gemini-')) delete saved.model;
  return { ...DEFAULTS, ...saved };
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!allowedSender(sender)) return false;
  (async () => {
    const config = await settings();
    if (message.type === 'GET_SETTINGS') return { ok: true, settings: { model: config.model, autoSolve: config.autoSolve, autoClick: config.autoClick, configured: Boolean(config.geminiApiKey) } };
    if (message.type !== 'SOLVE') throw new Error('Mensagem desconhecida.');
    const question = validateQuestion(message.question);
    const version = revision;
    const key = JSON.stringify([version, config.model, question]);
    if (cache.has(key)) return { ok: true, answer: cache.get(key) };
    if (!pending.has(key)) {
      const request = solveQuestion(question, config).then(answer => {
        if (revision === version) {
          if (cache.size >= 50) cache.delete(cache.keys().next().value);
          cache.set(key, answer);
        }
        return answer;
      }).finally(() => pending.delete(key));
      pending.set(key, request);
    }
    return { ok: true, answer: await pending.get(key) };
  })().then(respond, error => respond({ ok: false, error: error.message || 'Não foi possível resolver esta pergunta.' }));
  return true;
});

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== 'local' || !['geminiApiKey', 'model', 'autoSolve', 'autoClick'].some(key => key in changes)) return;
  revision++;
  cache.clear();
  const tabs = await chrome.tabs.query({});
  await Promise.allSettled(tabs.map(tab => chrome.tabs.sendMessage(tab.id, { type: 'SETTINGS_CHANGED' })));
});
