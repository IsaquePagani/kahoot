(() => {
  if (document.getElementById('kahoot-assistente')) return;
  const host = document.createElement('div');
  host.id = 'kahoot-assistente';
  host.style.cssText = 'all:initial;position:fixed;right:18px;bottom:18px;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `
    <style>
      :host { color-scheme: light; }
      * { box-sizing: border-box; }
      .card { font:14px/1.5 system-ui,sans-serif; width:320px; max-width:calc(100vw - 36px); background:#fff; color:#17251e; border:1px solid #cfe5d8; border-radius:18px; box-shadow:0 8px 40px #0003; overflow:hidden; }
      header { display:flex; align-items:center; justify-content:space-between; padding:14px 16px; background:#f0f8f3; }
      strong { font-size:15px; } .badge { color:#23764d; font-size:11px; text-transform:uppercase; letter-spacing:1px; }
      header button { background:none; border:0; font-size:20px; cursor:pointer; color:#446052; padding:0 4px; }
      section { padding:0 16px 16px; } p { margin:12px 0; } .status { color:#53645c; font-size:13px; }
      .result { white-space:pre-wrap; overflow-wrap:anywhere; max-height:240px; overflow:auto; }
      .solve { width:100%; background:#226647; color:white; border:0; border-radius:10px; padding:11px; font:600 14px system-ui; cursor:pointer; }
      .solve:disabled { opacity:.55; cursor:wait; } .note { font-size:11px; color:#687b70; margin-bottom:0; }
      [hidden] { display:none !important; }
    </style>
    <div class="card">
      <header><div><span class="badge">Assistente IA</span><br><strong>Kahoot</strong></div><button aria-label="Minimizar" title="Minimizar">−</button></header>
      <section><p class="status" role="status" aria-live="polite">Procurando pergunta…</p><p class="result" hidden></p><button class="solve">Resolver pergunta</button><p class="note">A IA pode errar. Configure a chave no ícone da extensão.</p></section>
    </div>`;
  document.documentElement.append(host);
  const status = root.querySelector('.status');
  const result = root.querySelector('.result');
  const button = root.querySelector('.solve');
  let config = { configured: false, autoSolve: false, autoClick: false };
  let currentKey = '';
  let busy = false;
  let requestId = 0;
  let attempted = '';
  let timer;
  let marked = [];
  let paused = false;

  root.querySelector('header button').addEventListener('click', event => {
    const section = root.querySelector('section');
    section.hidden = !section.hidden;
    event.currentTarget.textContent = section.hidden ? '+' : '−';
    event.currentTarget.setAttribute('aria-label', section.hidden ? 'Expandir' : 'Minimizar');
  });

  function clearMarks() {
    for (const { element, outline, offset } of marked) {
      element.style.outline = outline;
      element.style.outlineOffset = offset;
    }
    marked = [];
  }

  async function loadSettings() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
      if (!response?.ok) throw new Error(response?.error || 'Recarregue a página para reconectar a extensão.');
      config = response.settings;
      attempted = '';
      currentKey = '';
      requestId++;
      busy = false;
      scan();
    } catch (error) { status.textContent = error.message; }
  }

  function scan() {
    if (paused) return;
    const snapshot = KahootReader.read(document);
    if (snapshot.key !== currentKey) {
      currentKey = snapshot.key;
      requestId++;
      busy = false;
      clearMarks();
      result.hidden = true;
      result.textContent = '';
      status.textContent = snapshot.error || (config.configured ? 'Pergunta detectada. Pronto para resolver.' : 'Configure sua chave Gemini no ícone da extensão.');
    }
    button.disabled = busy || !snapshot.key || !config.configured;
    button.textContent = busy ? 'Consultando IA…' : 'Resolver pergunta';
    if (snapshot.key && config.autoSolve && config.configured && !busy && attempted !== snapshot.key) void solve(snapshot);
  }

  async function solve(snapshot = KahootReader.read(document)) {
    if (!snapshot.key || busy) return;
    currentKey = snapshot.key;
    attempted = snapshot.key;
    const id = ++requestId;
    busy = true;
    button.disabled = true;
    button.textContent = 'Consultando IA…';
    result.hidden = true;
    clearMarks();
    status.textContent = 'Lendo as alternativas e consultando a IA…';
    try {
      const response = await chrome.runtime.sendMessage({ type: 'SOLVE', question: { question: snapshot.question, answers: snapshot.answers } });
      const live = KahootReader.read(document);
      if (id !== requestId || live.key !== snapshot.key) return;
      if (!response?.ok) throw new Error(response?.error || 'A extensão foi desconectada. Recarregue a página.');
      const answer = response.answer;
      if (!answer.answerIndices.length) {
        status.textContent = 'A IA não conseguiu determinar a resposta.';
        result.textContent = answer.explanation;
        result.hidden = false;
        return;
      }
      status.textContent = 'Resposta sugerida pela IA';
      result.textContent = answer.answerIndices.map(i => `${i + 1}. ${live.answers[i]}`).join('\n') + '\n\n' + answer.explanation;
      result.hidden = false;
      for (const index of answer.answerIndices) {
        const element = live.elements[index];
        marked.push({ element, outline: element.style.outline, offset: element.style.outlineOffset });
        element.style.outline = '5px solid #16e87d';
        element.style.outlineOffset = '-5px';
      }
      if (config.autoClick && answer.answerIndices.length === 1 && answer.confidence >= 0.85) {
        // Revalidate immediately before the single irreversible interaction.
        const latest = KahootReader.read(document);
        if (latest.key === snapshot.key) {
          latest.elements[answer.answerIndices[0]].click();
          status.textContent = 'Resposta marcada automaticamente.';
        }
      }
    } catch (error) {
      if (id === requestId && KahootReader.read(document).key === snapshot.key) status.textContent = error.message;
    } finally {
      if (id === requestId) { busy = false; scan(); }
    }
  }

  button.addEventListener('click', () => void solve());
  chrome.runtime.onMessage.addListener(message => {
    if (message.type === 'SETTINGS_CHANGED') void loadSettings();
  });
  const observer = new MutationObserver(mutations => {
    if (mutations.every(m => m.target === host || host.contains(m.target))) return;
    clearTimeout(timer);
    timer = setTimeout(scan, 180);
  });
  observer.observe(document.body || document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['hidden', 'aria-hidden', 'disabled', 'aria-disabled', 'style', 'class'] });
  // Polling covers timers, visibility changes and DOM replacements during animations.
  setInterval(scan, 1500);
  document.addEventListener('visibilitychange', () => { paused = document.hidden; if (!paused) scan(); });
  void loadSettings();
})();
