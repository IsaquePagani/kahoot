import { DEFAULTS } from './lib/solver.js';

const form = document.getElementById('settings');
const key = document.getElementById('apiKey');
const status = document.getElementById('status');
const keyStatus = document.getElementById('keyStatus');
const remove = document.getElementById('removeKey');

async function refresh() {
  const settings = { ...DEFAULTS, ...await chrome.storage.local.get(['geminiApiKey', 'model', 'autoSolve', 'autoClick']) };
  if (!settings.model.startsWith('gemini-')) settings.model = DEFAULTS.model;
  document.getElementById('model').value = settings.model;
  document.getElementById('autoSolve').checked = settings.autoSolve;
  document.getElementById('autoClick').checked = settings.autoClick;
  key.placeholder = settings.geminiApiKey ? 'Chave salva • deixe vazio para manter' : 'Chave do Google AI Studio';
  keyStatus.textContent = settings.geminiApiKey ? 'Chave Gemini configurada neste perfil. Não é sincronizada.' : 'Use uma chave de projeto sem faturamento ativado.';
  remove.disabled = !settings.geminiApiKey;
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  try {
    const data = {
      model: document.getElementById('model').value.trim(),
      autoSolve: document.getElementById('autoSolve').checked,
      autoClick: document.getElementById('autoClick').checked
    };
    if (!/^gemini-[a-zA-Z0-9._-]+$/.test(data.model)) throw new Error('Informe um identificador de modelo Gemini válido.');
    if (key.value.trim()) data.geminiApiKey = key.value.trim();
    await chrome.storage.local.set(data);
    key.value = '';
    await refresh();
    status.textContent = 'Salvo! Volte à aba do Kahoot.';
  } catch (error) { status.textContent = error.message; }
});

remove.addEventListener('click', async () => {
  try {
    await chrome.storage.local.remove('geminiApiKey');
    key.value = '';
    await refresh();
    status.textContent = 'Chave removida.';
  } catch (error) { status.textContent = error.message; }
});
refresh().catch(error => { status.textContent = error.message; });
